#include <iostream>
#include "Vector.h"
using namespace std;

int main() {
	Vector aVec;
	aVec.consoleFill();
	aVec.sort();
}