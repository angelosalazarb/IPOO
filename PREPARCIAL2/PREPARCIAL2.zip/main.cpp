#include <string>
#include <iostream>
using namespace std;

int main(){
  cout << "hola" << endl;
}